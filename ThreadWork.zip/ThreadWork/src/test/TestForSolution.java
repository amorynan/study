package test;
import solution.AirCheck;
import org.junit.Test;

public class TestForSolution {

    @Test
    public void test() {
        String s = AirCheck.valid(4, 6, "GDGDSDSD");
        String s1 = AirCheck.valid(101, 4, "FSDSFFF");
        String s2 = AirCheck.valid(2, 101, "DFFSSS");
        if ("Invalid cell type".equals(s)){
            System.out.println("false");
        }
        if ("Incorrect mesh size".equals(s1)){
            System.out.println("false");
        }
        if ("Data mismatch".equals(s2)){
            System.out.println("false");
        }
    }
}
