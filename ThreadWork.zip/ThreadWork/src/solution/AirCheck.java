package solution;

import java.util.Scanner;

public class AirCheck {

    /**
     * 作为数据校验
     * @param width
     * @param length
     * @param s
     * @return
     */
    public static String valid(int width, int length, String s) {
        if (width > 100 || length > 100){
            return "Incorrect mesh size";
        }
        if (s.length() != width * length) {
            return "Data mismatch";
        }
        for (int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) != 'R' && s.charAt(i) != 'G' && s.charAt(i) != 'F') {
                return "Invalid cell type";
            }
        }

        return null;
    }

    /**
     * 需要反转字符串
     * @param s
     * @return
     */
    public static String reverseString(String s){
        char[] cs = s.toCharArray();
        for (int i = 0; i < s.length() / 2 && cs[i] != cs[s.length() - 1 - i]; ++i) {
            char temp = cs[i];
            cs[i] = cs[s.length() - 1 -i];
            cs[s.length() - 1 - i] = temp;
        }
        return new String(cs);
    }

    public static void main(String[] args) {
        Scanner scanner  = new Scanner(System.in);
        int width = scanner.nextInt();
        int length = scanner.nextInt();
        String s = scanner.next();

        String res = valid(width, length, s);
        if (res == null) {
            boolean flag = true;
            for (int i = 0; i < s.length(); i+=length) {
                if (flag) {
                    System.out.println(s.substring(i, i + length));
                    flag = !flag;
                }else{
                    System.out.println(reverseString(s.substring(i, i+length)));
                    flag = !flag;
                }
            }
        }

    }
}
